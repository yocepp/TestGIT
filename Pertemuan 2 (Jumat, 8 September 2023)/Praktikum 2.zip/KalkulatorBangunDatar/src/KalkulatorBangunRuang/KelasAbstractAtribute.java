/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KalkulatorBangunRuang;

/**
 *
 * @author ASUS
 */
public abstract class KelasAbstractAtribute {
    public double panjang;
    public double Lebar;
    public double Tinggi;
    public double sisi;
    public abstract void printResult();
}
